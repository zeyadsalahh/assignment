const express = require('express');
const fs = require('fs');
const app = express();
app.use(express.json());

const STUDENTS_FILE = 'students.json';
if (!fs.existsSync(STUDENTS_FILE)) {
  fs.writeFileSync(STUDENTS_FILE, JSON.stringify([]));
}

app.post('/student', (req, res) => {
  const { name, email, course } = req.body;
  if (!name || !email || !course) {
    return res.status(400).json({ error: 'All fields required' });
  }
  const students = JSON.parse(fs.readFileSync(STUDENTS_FILE));
  students.push({ name, email, course });
  fs.writeFileSync(STUDENTS_FILE, JSON.stringify(students));
  res.status(201).json({ message: 'Student added' });
});

app.get('/students', (req, res) => {
  const students = JSON.parse(fs.readFileSync(STUDENTS_FILE));
  res.json(students);
});

app.listen(3000, () => console.log('Server running on 3000'));