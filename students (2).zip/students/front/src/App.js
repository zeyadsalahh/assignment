import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [currentView, setCurrentView] = useState('add'); // 'add' or 'view'
  const [studentList, setStudentList] = useState([]);
  const [studentName, setStudentName] = useState('');
  const [studentEmail, setStudentEmail] = useState('');
  const [studentCourse, setStudentCourse] = useState('');

  // Load students when switching to view
  useEffect(() => {
    if (currentView === 'view') {
      fetch('/students')
        .then(response => response.json())
        .then(data => setStudentList(data))
        .catch(error => console.error('Error loading students:', error));
    }
  }, [currentView]);

  // Handle form submission
  const addStudent = (event) => {
    event.preventDefault();
    fetch('/student', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: studentName,
        email: studentEmail,
        course: studentCourse
      })
    })
      .then(() => {
        // Clear form and show success
        setStudentName('');
        setStudentEmail('');
        setStudentCourse('');
        alert('Student added successfully!');
      })
      .catch(error => console.error('Error adding student:', error));
  };

  return (
    <div className="App">
      <h1>Student Dashboard</h1>
      <button onClick={() => setCurrentView('add')}>Add Student</button>
      <button onClick={() => setCurrentView('view')}>View Students</button>
      
      {currentView === 'add' && (
        <form onSubmit={addStudent}>
          <input
            type="text"
            placeholder="Enter name"
            value={studentName}
            onChange={(e) => setStudentName(e.target.value)}
            required
          />
          <input
            type="email"
            placeholder="Enter email"
            value={studentEmail}
            onChange={(e) => setStudentEmail(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Enter course"
            value={studentCourse}
            onChange={(e) => setStudentCourse(e.target.value)}
            required
          />
          <button type="submit">Add Student</button>
        </form>
      )}
      
      {currentView === 'view' && (
        <ul>
          {studentList.map((student, index) => (
            <li key={index}>
              {student.name} - {student.email} - {student.course}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;
